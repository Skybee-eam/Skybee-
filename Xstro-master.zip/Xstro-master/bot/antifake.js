import { isJidGroup } from 'baileys';

export async function Antifake(msg) {}
