import { getChatSummary, getName } from '../../sql/store.js';

 console.log(await getChatSummary());

// console.log(await getName('2349027862116@s.whatsapp.net'))